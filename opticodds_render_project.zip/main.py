
from flask import Flask, request
import requests

app = Flask(__name__)

@app.route('/send-ip', methods=['POST'])
def send_ip():
    data = request.json
    ip = data.get("ip")

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
    }

    # TODO: Replace this URL with the actual destination
    response = requests.post("https://example.com/receive",  # Change to actual opticodds endpoint
                             json={"ip": ip},
                             headers=headers)

    return {"status": "sent", "opticodds_status": response.status_code}

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
